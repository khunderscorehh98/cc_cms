<template>
  <v-container fluid class="pa-0 ma-0">
    <v-row class="pa-0 ma-0">
      <span class="text-h5"><strong>Notification</strong></span>
      <hr />
      <v-col class="pa-0 ma-0">
        <!-- Loop through the activityLogs -->
        <div 
          v-for="(log, index) in activityLogs"
          :key="index"
        >
          <v-card class="ma-2 pa-2">
            <v-card-title class="text-h6">
              {{ log.activity_type }} (Log ID: {{ log.log_id }})
            </v-card-title>
            <v-card-subtitle>
              Company ID: {{ log.company_id }} | User ID: {{ log.user_id }}
            </v-card-subtitle>
            <v-card-text>
              <strong>Details:</strong> {{ log.details }}
              <br />
              <strong>Table Name:</strong> {{ log.table_name }}
              <br />
              <strong>Timestamp:</strong> {{ log.timestamp }}
            </v-card-text>
          </v-card>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      activityLogs: [], // Holds data from the global Axios instance
    };
  },
  mounted() {
    // // Fetch the activity logs
    // this.$axios
    //   .get('/activity_log') // Use the globally set base URL
    //   .then((response) => {
    //     this.activityLogs = response.data; // Store the fetched data
    //   })
    //   .catch((error) => {
    //     console.error('Error fetching activity logs:', error);
    //   });
  },
};
</script>

<style lang="scss" scoped>
.v-container,
.v-row,
.v-col,
.v-card {
  margin: 0 !important;
  padding: 0 !important;
}
</style>
