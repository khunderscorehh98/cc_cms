<template>
  <v-container fluid class="pa-0 ma-0">
    <v-row class="pa-0 ma-0">
      <v-col class="pa-0 ma-0">
        <v-card>
          <v-container>
            <span class="text-h5"><strong>Notification</strong></span>
            <br>
            <hr>
            <br>
            <em>Sample</em>
          </v-container>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  // Add any component logic if needed
};
</script>

<style lang="scss" scoped>
.v-container,
.v-row,
.v-col,
.v-card {
  margin: 0 !important;
  padding: 0 !important;
}
</style>
